===============
 About
===============

Snowbird helps configure Snowflake resources for dataproducts. Snowbird builds on Permifrost.

===============
 Installation
===============

pip install snowbird

===============
 Example
===============

The default declaration file name is 'snowflake.yml' and the default location of the file is ./infrastructure

In this case you can simply run the command: $ snowbird run 


